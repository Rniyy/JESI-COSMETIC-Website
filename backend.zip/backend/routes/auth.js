
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const pool = require('../db/pool');

const {
  issueToken,
  clearToken,
  requireAuth
} = require('../middleware/authMiddleware');

const { mergeGuestCartAndWishlist } = require('../utils/mergeGuestData');
const { sendPasswordResetEmail } = require('../utils/mailer');

const RESET_TOKEN_TTL_MS = 1000 * 60 * 30;

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (
      typeof name !== 'string' ||
      typeof email !== 'string' ||
      typeof password !== 'string' ||
      !name.trim() ||
      !email.trim() ||
      !password
    ) {
      return res.status(400).json({
        success: false,
        message: 'name, email and password are required'
      });
    }

    if (password.length < 8) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 8 characters'
      });
    }

    const normalizedName = name.trim();
    const normalizedEmail = email.trim().toLowerCase();

    const [[existing]] = await pool.query(
      'SELECT id FROM users WHERE email = ?',
      [normalizedEmail]
    );

    if (existing) {
      return res.status(409).json({
        success: false,
        message: 'An account with that email already exists'
      });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const [result] = await pool.query(
      `INSERT INTO users (name, email, password_hash, role)
       VALUES (?, ?, ?, ?)`,
      [normalizedName, normalizedEmail, passwordHash, 'user']
    );

    const user = {
      id: result.insertId,
      name: normalizedName,
      email: normalizedEmail,
      role: 'user'
    };

    await mergeGuestCartAndWishlist(pool, req.sessionId, user.id);

    issueToken(res, user);

    return res.status(201).json({
      success: true,
      data: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        hasPaymentPin: false
      }
    });
  } catch (err) {
    console.error('POST /auth/register error:', err);

    return res.status(500).json({
      success: false,
      message: 'Failed to register'
    });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (
      typeof email !== 'string' ||
      typeof password !== 'string' ||
      !email.trim() ||
      !password
    ) {
      return res.status(400).json({
        success: false,
        message: 'email and password are required'
      });
    }

    const normalizedEmail = email.trim().toLowerCase();

    // Temporary diagnostics: verify the backend database connection.
    const [[dbInfo]] = await pool.query(
      'SELECT DATABASE() AS db, @@hostname AS host, @@port AS port'
    );

    console.log('[DB DEBUG]', dbInfo);

    // Read the account using the same connection as login.
    const [[user]] = await pool.query(
      `SELECT id, name, email, password_hash, role, payment_pin_hash
       FROM users
       WHERE email = ?
       LIMIT 1`,
      [normalizedEmail]
    );

    console.log('[LOGIN USER FROM DB]', {
      id: user ? user.id : null,
      email: user ? user.email : null,
      role: user ? user.role : null
    });

    if (!user) {
      console.log('[LOGIN DEBUG] Account not found');

      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    const match = await bcrypt.compare(password, user.password_hash);

    console.log('[LOGIN DEBUG]', {
      userFound: true,
      passwordMatches: match,
      role: user.role
    });

    if (!match) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // Use the role returned by the database; do not hardcode it.
    const authenticatedUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    };

    await mergeGuestCartAndWishlist(pool, req.sessionId, user.id);

    issueToken(res, authenticatedUser);

    return res.json({
      success: true,
      data: {
        id: authenticatedUser.id,
        name: authenticatedUser.name,
        email: authenticatedUser.email,
        role: authenticatedUser.role,
        hasPaymentPin: !!user.payment_pin_hash
      }
    });
  } catch (err) {
    console.error('POST /auth/login error:', err);

    return res.status(500).json({
      success: false,
      message: 'Failed to log in'
    });
  }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  clearToken(res);

  return res.json({ success: true });
});

// GET /api/auth/me
router.get('/me', async (req, res) => {
  if (!req.user) {
    return res.json({ success: true, data: null });
  }

  try {
    const [[user]] = await pool.query(
      `SELECT id, name, email, role, payment_pin_hash
       FROM users
       WHERE id = ?`,
      [req.user.id]
    );

    if (!user) {
      return res.json({ success: true, data: null });
    }

    const { payment_pin_hash, ...safeUser } = user;

    return res.json({
      success: true,
      data: {
        ...safeUser,
        hasPaymentPin: !!payment_pin_hash
      }
    });
  } catch (err) {
    console.error('GET /auth/me error:', err);

    return res.status(500).json({
      success: false,
      message: 'Failed to fetch current user'
    });
  }
});

// POST /api/auth/forgot-password
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

    if (typeof email !== 'string' || !email.trim()) {
      return res.status(400).json({
        success: false,
        message: 'email is required'
      });
    }

    const normalizedEmail = email.trim().toLowerCase();

    const [[user]] = await pool.query(
      'SELECT id, email FROM users WHERE email = ?',
      [normalizedEmail]
    );

    if (user) {
      const rawToken = crypto.randomBytes(32).toString('hex');

      const tokenHash = crypto
        .createHash('sha256')
        .update(rawToken)
        .digest('hex');

      const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MS);

      await pool.query(
        `INSERT INTO password_reset_tokens
           (user_id, token_hash, expires_at)
         VALUES (?, ?, ?)`,
        [user.id, tokenHash, expiresAt]
      );

      await sendPasswordResetEmail(user.email, rawToken);
    }

    return res.json({
      success: true,
      message: 'If that email is registered, a reset link has been sent.'
    });
  } catch (err) {
    console.error('POST /auth/forgot-password error:', err);

    return res.status(500).json({
      success: false,
      message: 'Failed to process request'
    });
  }
});

// POST /api/auth/reset-password
router.post('/reset-password', async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    if (
      typeof token !== 'string' ||
      typeof newPassword !== 'string' ||
      !token ||
      !newPassword
    ) {
      return res.status(400).json({
        success: false,
        message: 'token and newPassword are required'
      });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 8 characters'
      });
    }

    const tokenHash = crypto
      .createHash('sha256')
      .update(token)
      .digest('hex');

    const [[resetRow]] = await pool.query(
      `SELECT id, user_id, expires_at, used_at
       FROM password_reset_tokens
       WHERE token_hash = ?`,
      [tokenHash]
    );

    if (
      !resetRow ||
      resetRow.used_at ||
      new Date(resetRow.expires_at) < new Date()
    ) {
      return res.status(400).json({
        success: false,
        message: 'This reset link is invalid or has expired'
      });
    }

    const passwordHash = await bcrypt.hash(newPassword, 12);

    await pool.query(
      'UPDATE users SET password_hash = ? WHERE id = ?',
      [passwordHash, resetRow.user_id]
    );

    await pool.query(
      'UPDATE password_reset_tokens SET used_at = NOW() WHERE id = ?',
      [resetRow.id]
    );

    return res.json({
      success: true,
      message: 'Password updated — you can now log in with your new password.'
    });
  } catch (err) {
    console.error('POST /auth/reset-password error:', err);

    return res.status(500).json({
      success: false,
      message: 'Failed to reset password'
    });
  }
});

// PATCH /api/auth/me
router.patch('/me', requireAuth, async (req, res) => {
  try {
    const { name, email } = req.body;

    if (
      typeof name !== 'string' ||
      typeof email !== 'string' ||
      !name.trim() ||
      !email.trim()
    ) {
      return res.status(400).json({
        success: false,
        message: 'name and email are required'
      });
    }

    const normalizedName = name.trim();
    const normalizedEmail = email.trim().toLowerCase();

    const [[existing]] = await pool.query(
      'SELECT id FROM users WHERE email = ? AND id != ?',
      [normalizedEmail, req.user.id]
    );

    if (existing) {
      return res.status(409).json({
        success: false,
        message: 'Another account already uses that email'
      });
    }

    await pool.query(
      'UPDATE users SET name = ?, email = ? WHERE id = ?',
      [normalizedName, normalizedEmail, req.user.id]
    );

    return res.json({
      success: true,
      data: {
        id: req.user.id,
        name: normalizedName,
        email: normalizedEmail,
        role: req.user.role
      }
    });
  } catch (err) {
    console.error('PATCH /auth/me error:', err);

    return res.status(500).json({
      success: false,
      message: 'Failed to update profile'
    });
  }
});

// PATCH /api/auth/password
router.patch('/password', requireAuth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (
      typeof currentPassword !== 'string' ||
      typeof newPassword !== 'string' ||
      !currentPassword ||
      !newPassword
    ) {
      return res.status(400).json({
        success: false,
        message: 'currentPassword and newPassword are required'
      });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        success: false,
        message: 'New password must be at least 8 characters'
      });
    }

    const [[user]] = await pool.query(
      'SELECT password_hash FROM users WHERE id = ?',
      [req.user.id]
    );

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    const match = await bcrypt.compare(
      currentPassword,
      user.password_hash
    );

    if (!match) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    const newHash = await bcrypt.hash(newPassword, 12);

    await pool.query(
      'UPDATE users SET password_hash = ? WHERE id = ?',
      [newHash, req.user.id]
    );

    return res.json({
      success: true,
      message: 'Password updated'
    });
  } catch (err) {
    console.error('PATCH /auth/password error:', err);

    return res.status(500).json({
      success: false,
      message: 'Failed to update password'
    });
  }
});

module.exports = router;